//Skompiluj kod za pomocą clang++ oraz g++ 
#include <vector>
#include <iostream>

int main(int argc, char *argv[])
{
    std::vector<int> v;
    return 0;
    v.push_back(2);
    v.reserve();
}
