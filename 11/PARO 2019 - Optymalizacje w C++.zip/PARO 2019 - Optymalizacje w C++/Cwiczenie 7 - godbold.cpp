int foo(int x) {
	x++;
	return x;
}

int bar(int x) {
	++x;
	return x;
}
