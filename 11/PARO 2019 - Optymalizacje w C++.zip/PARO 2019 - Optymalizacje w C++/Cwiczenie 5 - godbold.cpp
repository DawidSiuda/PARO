int foo(int x, int y) {
	x = x + y;
	return x;
}

int bar(int x, int y) {
	x += y;
	return x;
}
