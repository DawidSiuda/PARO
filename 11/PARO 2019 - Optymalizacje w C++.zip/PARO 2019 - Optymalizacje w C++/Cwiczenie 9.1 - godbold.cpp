enum class color {
	black,
	maroon,
	green,
	olive,
	navy,
	purple,
	teal,
	silver,
	gray,
	red,
	lime,
	yellow,
	blue,
	fuchsia,
	aqua,
	white
};
