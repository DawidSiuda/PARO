int foo(int x) {
	x = x + 1;
	return x;
}

int bar(int x) {
	++x;
	return x;
}
