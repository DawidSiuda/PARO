int foo(int x) {
	return x * 2;
}

int bar(int x) {
	return x << 1;
}
