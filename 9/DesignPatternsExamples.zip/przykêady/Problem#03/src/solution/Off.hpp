#pragma once
#include "State.hpp"

namespace FSM
{

class Off : public DeviceState
{
public:
    Off(StateTransitionFunc stateTransitionFunc,
         std::shared_ptr<std::string> sharedTaskName)
        :DeviceState(stateTransitionFunc, sharedTaskName)
    {
    }

    void runTask(std::string name) override
    {
        //implement me ...
    }

    void stopTask() override
    {
        //implement me ...
    }

    void coolDown() override
    {
        //implement me ...
    }
};

}
