#pragma once
#include "State.hpp"

namespace FSM
{

class Overheated : public DeviceState
{
public:
    Overheated(StateTransitionFunc stateTansitionFunc,
         std::shared_ptr<std::string> sharedTaskName)
        :DeviceState(stateTansitionFunc, sharedTaskName)
    {
    }

    void runTask(std::string name) override
    {
        //implement me ...
    }

    void stopTask() override
    {
        //implement me ...
    }

    void coolDown() override
    {
        //implement me ...
    }
};

}
