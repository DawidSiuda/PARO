#pragma once
#include "State.hpp"
#include <string>
#include <memory>

namespace FSM
{

class Run : public DeviceState
{
public:
    Run(StateTransitionFunc stateTransitionFunc,
          std::shared_ptr<std::string> sharedTaskName)
        : DeviceState(stateTransitionFunc, sharedTaskName)

    {
    }

    void runTask(std::string name) override
    {
        //implement me ...
    }

    void stopTask() override
    {
        //implement me ...
    }
    void coolDown() override
    {
        //implement me ...
    }
};

}
