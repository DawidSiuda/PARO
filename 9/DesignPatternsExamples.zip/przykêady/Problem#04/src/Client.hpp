#pragma once

#include <map>
#include "PIT.hpp"

using year = int;
using tax = int;

class Client
{
protected:
    std::map <year, tax> history;
public:
    virtual void calculateTax(PIT) = 0;
    void printHistory()
    {
        for(auto a: history)
        {
            std::cout << a.first << ": " << a.second << std::endl;
        }
    }
};
