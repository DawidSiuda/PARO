#include "Client.hpp"

class NonLinear: public Client
{
public:
    void calculateTax(PIT p) override
    {
        int taxationBase = p.income - calculateTaxFreeAllowance(p.income) - p.costs;
        history[p.year] = taxationBase * getTaxRate(p.income);
    }
private:
    int calculateTaxFreeAllowance(int income)
    {
        if (income < 8000)
        {
            return income;
        }
        else if (income < 13000)
        {
            int difference = income - 8000;
            float proportion = difference / 4999;
            return 3091 + proportion * 4909;
        }
        else if (income < 85529)
        {
            return 3091;
        }
        else if (income < 127000)
        {
            int difference = income - 85529;
            float proportion = difference / 41471;
            return proportion * 3091;
        }
        return 0;
    }

    float getTaxRate(int income)
    {
        if (income < 85529)
            return 0.18;
        return 0.32;
    }
};