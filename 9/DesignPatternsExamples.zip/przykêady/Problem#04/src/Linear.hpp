#include "Client.hpp"

class Linear: public Client
{
public:
    void calculateTax(PIT p) override
    {
        history[p.year] = (p.income - p.costs) * 0.19;
    }
};