#include <iostream>

#include "LumpSum.hpp"
#include "NonLinear.hpp"
#include "Linear.hpp"
#include "FlatRate.hpp"

int main()
{
    LumpSum clientOne;
    NonLinear clientTwo;
    Linear clientThree;
    FlatRate clientFour;

    PIT y2016 {2016, 300000, 10000};
    PIT y2017 {2017, 10000, 3000};
    PIT y2018 {2018, 100000, 10000};

    clientOne.calculateTax(y2016);
    clientOne.calculateTax(y2017);
    clientOne.calculateTax(y2018);
    std::cout << "LumpSum: " << std::endl;
    clientOne.printHistory();

    clientTwo.calculateTax(y2016);
    clientTwo.calculateTax(y2017);
    clientTwo.calculateTax(y2018);
    std::cout << "NonLinear: " << std::endl;
    clientTwo.printHistory();

    clientThree.calculateTax(y2016);
    clientThree.calculateTax(y2017);
    clientThree.calculateTax(y2018);
    std::cout << "Linear: " << std::endl;
    clientThree.printHistory();

    clientFour.calculateTax(y2016);
    clientFour.calculateTax(y2017);
    clientFour.calculateTax(y2018);
    std::cout << "FlatRate: " << std::endl;
    clientFour.printHistory();
}
