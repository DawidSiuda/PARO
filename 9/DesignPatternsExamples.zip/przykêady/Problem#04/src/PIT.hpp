#pragma once

struct PIT
{
    int year;
    int income;
    int costs;
};