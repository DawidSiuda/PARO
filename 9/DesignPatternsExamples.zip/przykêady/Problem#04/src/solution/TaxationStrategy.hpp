#pragma once

#include <utility>

#include "PIT.hpp"

class TaxationStrategy
{
public:
    virtual pair<year, tax> calculateTax(PIT) = 0;
};
