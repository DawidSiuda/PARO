#include "Client.hpp"

class LumpSum: public Client
{
public:
    void calculateTax(PIT p) override
    {
        history[p.year] = p.income * 0.17;
    }
};