#include "Client.hpp"

class FlatRate: public Client
{
public:
    void calculateTax(PIT p) override
    {
        history[p.year] = 500;
    }
};