#pragma once
#include <Database.hpp>
#include <iostream>

class Chart
{
public:
    Chart(Database& db)
        :database(db)
    {
    }

    void plot()
    {
        std::cout << "Chart::plot()   " << database.getData("chart") << "\n";
    }

private:
    Database& database;
};

class Calculator
{
public:
    Calculator(Database& db)
        :database(db)
    {
    }

    void recalculate()
    {
        std::cout << "Calculator::recalculate()   " << database.getData("calculator") << "\n";
    }

private:
    Database& database;
};

class EmailSender
{
public:
    EmailSender(Database& db)
        :database(db)
    {
    }

    void send()
    {
        std::cout << "EmailSender::send()   " << database.getData("email") << "\n";
    }

private:
    Database& database;
};
