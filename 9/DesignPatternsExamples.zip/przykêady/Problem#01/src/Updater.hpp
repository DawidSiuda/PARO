#include <iostream>

class Updater{
public:
    Updater(){throw 666;}
    void checkForUpdates(){
        std::cout << "checking for updates" << std::endl;
    }
};
