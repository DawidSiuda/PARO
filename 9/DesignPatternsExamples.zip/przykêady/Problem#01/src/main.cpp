#include <iostream>

#include <Updater.hpp>

int main(){
    Updater updater;
    char choice = 'a';
    while (choice != 'e'){
        std::cout << "r- run\nu- check for updates\ne- exit" << std::endl;
        std::cin >> choice; std::cin.ignore();
        switch (choice){
        case 'r':
            std::cout << "hello world" << std::endl;
            break;
        case 'u':
            updater.checkForUpdates();
            break;
        }
    }
}
