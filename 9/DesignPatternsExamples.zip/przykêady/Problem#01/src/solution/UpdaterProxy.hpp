#include <Updater.hpp>

class UpdaterProxy
{
    //Iplement a proxy here.
};

