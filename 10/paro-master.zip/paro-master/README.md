# Praktyczne Aspekty Rozwoju Oprogramowania

materiały na zajęcia.
