#pragma once

bool isPrime(const unsigned n);
